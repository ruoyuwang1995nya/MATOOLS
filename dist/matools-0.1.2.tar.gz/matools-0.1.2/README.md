# matools
Lightweight alternative to pymatgen for simple crystal structure manipulation

The project is based around a structure class with methods providing I/O interface and functionalities such as volume, lattice constant, etc. It is basis for some of my other scripts for input generation/data processing.

The usage of this MATOOLS is self-explainatory

# scripts
Scripts built on functionalites of MATOOLS module
## pos2sheng.py
A simple script which transforms POSCAR file into CONTROL file of ShengBTE
