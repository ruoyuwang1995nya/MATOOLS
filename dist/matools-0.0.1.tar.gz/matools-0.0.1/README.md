# matools
Lightweight alternative to pymatgen for simple crystal structure manipulation

The project is based around a structure class with methods providing I/O interface and functionalities such as volume, lattice constant, etc. It is basis for some of my other scripts for input generation/data processing.
